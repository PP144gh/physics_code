#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include <cairo.h>
#include <math.h>


typedef struct
{
  gint x, y;
  gint flag_move;// Esta a "1" quando o rato esta carregado na lente 1 e a 2 na lente 2 e a "0" quando larga.
  gdouble     ratoPos[2];// Posicao do rato
  gdouble     press[2];// Posicao em que foi carregado o botao do rato
  gchar str1[20];
  gdouble centroe1[2];//coordenadas centro elipse 1
  gdouble centroe2[2];//coordenadas centro elipse 2
  gdouble deltax;//inicializado com um nr negativo pq no decorrer do programa vai ter sempre valores positivos. permite dar valores iniciais às variaveis.
  gdouble deltarato;
  gdouble f1;
  gdouble f2;
  gdouble xobj;
  gdouble xi1;
  gdouble dimobj;
  gdouble dimi1;
  gdouble dl2i1;
  gdouble dl1i1;
  gdouble magl1;
  gdouble magl2;
  gdouble dl2i2;
  gdouble dl1i2;
  gdouble xi2;
  gdouble dimi2;
  GtkAdjustment *adj[4];
  GtkWidget *hscale[4];
  GtkWidget *window;
}global;
 

//area desenho
gboolean
on_expose_event (GtkWidget      *widget,
		 GdkEventExpose *event,
		 gpointer data         )
{
  global *glob;
  cairo_t       *cr;
  double a,b;
  static const double dashed1[] = {3.0};


  glob=(global *) data;

 gtk_window_get_size (GTK_WINDOW(glob->window), &glob->x, &glob->y);

 //adptar dfocal as dimensoes da janela
gtk_adjustment_set_upper (glob->adj[0],(gdouble)1+glob->x*0.2);
  gtk_adjustment_set_upper (glob->adj[1],(gdouble)1+glob->x*0.2);
 
 
  //adptar x max do objeto tendo em conta a janela e a posiçao da objetiva
      gtk_adjustment_set_upper (glob->adj[2],(gdouble)(1+glob->centroe1[0]-glob->x*0.05));


 gtk_adjustment_set_upper (glob->adj[3],(gdouble)1+glob->x*0.06);//altura das lentes

  if(glob->deltax<0)
    {

      glob->centroe1[0]=(glob->x)*0.1875; //xno ref inicial:181
      glob->centroe1[1]=(glob->y)*0.35;
      glob->centroe2[0]=(glob->x)*0.538333;//xno ref inicial: 520
      glob->centroe2[1]=(glob->y)*0.35;
    }
  glob->deltax=fabs(glob->centroe1[0]-glob->centroe2[0]);
  glob->f1=gtk_adjustment_get_value (glob->adj[0]);
  glob->f2=gtk_adjustment_get_value (glob->adj[1]);
   glob->xobj=glob->x*0.05+gtk_adjustment_get_value(glob->adj[2]);
glob->dimobj=gtk_adjustment_get_value(glob->adj[3]);

  cr = gdk_cairo_create (glob->window->window);
  

  //coords rato ref
  cairo_move_to(cr, glob->x*0.017, glob->y*0.9);//coords janela padrao x: 140 y:540
  sprintf (glob->str1, "Rato no ref: %4d %4d",(int) (glob->ratoPos[0]-glob->x*0.05), (int)(glob->y*0.5-glob->ratoPos[1]));
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr);

  //d lentes
  cairo_move_to(cr, glob->x*0.117, glob->y*0.9);//coords janela padrao x: 140 y:540
  sprintf (glob->str1, "D lentes: %4.1lf",glob->deltax);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

  //d obj lente1
  cairo_move_to(cr, glob->x*0.117, glob->y*0.933);//coords janela padrao x: 140 y:560
  sprintf (glob->str1, "d obj lente1: %4.1lf",fabs(glob->centroe1[0]-glob->xobj));
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

//d obj lente2
  cairo_move_to(cr, glob->x*0.117, glob->y*0.967);//coords janela padrao x: 140 y:580
  sprintf (glob->str1, "d obj lente2: %4.1lf",fabs(glob->centroe2[0]-glob->xobj));
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

  //dimensao objeto
cairo_move_to(cr, glob->x*0.2,glob->y*0.9);//coords janela padrao x: 240 y:560
  sprintf (glob->str1, "dimensao objeto: %4.1lf",glob->dimobj);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

  //dimensão imagem1
cairo_move_to(cr, glob->x*0.2,glob->y*0.933);//coords janela padrao x: 240 y:580
 sprintf (glob->str1, "dimensao imagem1: %4.1lf",fabs(glob->dimi1));
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

 //dimensão imagem2
cairo_move_to(cr, glob->x*0.2,glob->y*0.967);//coords janela padrao x: 240 y:580
 sprintf (glob->str1, "dimensao imagem2: %4.1lf",fabs(glob->dimi2));
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

  //x lente 1
  cairo_move_to(cr, glob->x*0.017, glob->y*0.933); //coords janela padrao x: 20 y:560
  sprintf (glob->str1, "x lente1: %4.1lf",glob->centroe1[0]-glob->x*0.05);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

  //x lente 2
  cairo_move_to(cr, glob->x*0.017, glob->y*0.967);//coords janela padrao x: 20 y:580
  sprintf (glob->str1, "x lente2: %4.1lf",glob->centroe2[0]-glob->x*0.05);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

//d ima1 lente1
  cairo_move_to(cr, glob->x*0.32, glob->y*0.933);//coords janela padrao x: 140 y:560
  sprintf (glob->str1, "d i1 lente1: %4.1lf",glob->dl1i1);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

//d ima1 lente2
  cairo_move_to(cr, glob->x*0.32, glob->y*0.967);//coords janela padrao x: 140 y:580
  sprintf (glob->str1, "d i1 lente2: %4.1lf",glob->dl2i1);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

 //x i 1
  cairo_move_to(cr, glob->x*0.32,glob->y*0.9); //coords janela padrao x: 20 y:560
  sprintf (glob->str1, "x i1: %4.1lf",glob->xi1-glob->x*0.05);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

//d ima2 lente1
  cairo_move_to(cr, glob->x*0.42, glob->y*0.933);//coords janela padrao x: 140 y:560
  sprintf (glob->str1, "d i2 lente1: %4.1lf",glob->dl1i2);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

//d ima2 lente2
  cairo_move_to(cr, glob->x*0.42, glob->y*0.967);//coords janela padrao x: 140 y:580
  sprintf (glob->str1, "d i2 lente2: %4.1lf",glob->dl2i2);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 

 //x i 2
  cairo_move_to(cr, glob->x*0.42,glob->y*0.9); //coords janela padrao x: 20 y:560
  sprintf (glob->str1, "x i2: %4.1lf",glob->xi2-glob->x*0.05);
  cairo_show_text  (cr, glob->str1);
  cairo_stroke(cr); 




 
  // Referencial
  //horizontal
  cairo_set_source_rgb (cr, 0, 0, 0);//cor
  cairo_set_line_width(cr, 2);
  cairo_move_to(cr, 0, glob->y*0.35);
  cairo_line_to(cr, glob->x*0.6, glob->y*0.35 );
  cairo_stroke(cr);

  //vertical
  cairo_set_source_rgb (cr, 0, 0, 0);
  cairo_set_line_width(cr, 2);
  cairo_move_to(cr, glob->x*0.05, glob->y*0.8);
  cairo_line_to(cr, glob->x*0.05, glob->y*0.1);
  cairo_stroke(cr);


  //elipse 1
  cairo_set_source_rgb (cr, 0, 0.75, 1);
  cairo_translate(cr,glob->centroe1[0],glob->centroe1[1]); //coordenadas centro elipse
  cairo_scale(cr, 0.15,2);// no tamanho padrao da janela a razao x:y é 0.15:2 "diametro"x elipse = 10.8; "diametro"y elipse = 72
  cairo_arc(cr, 0, 0, glob->x*0.03, 0, 2*M_PI);
  cairo_fill(cr);
  cairo_stroke(cr);

  //elipse 2
  cairo_identity_matrix(cr);
  cairo_set_source_rgb (cr, 0.44, 0.62, 0.94); 
  cairo_translate(cr,glob->centroe2[0],glob->centroe2[1]); //coordenadas centro elipse
  cairo_scale(cr, 0.15,2);//"diametro"x elipse = 10.8; "diametro"y elipse = 72
  cairo_arc(cr, 0, 0, glob->x*0.03, 0, 2*M_PI); //raio padrao = 36
  cairo_fill(cr); 
  cairo_stroke(cr); 

  //f1
  cairo_identity_matrix(cr);
  cairo_set_source_rgb(cr, 0, 0, 0);
  cairo_translate(cr,glob->centroe1[0]+glob->f1,glob->y*0.35);

  cairo_arc (cr,0, 0, 3, 0, 2*M_PI);
     

  cairo_select_font_face(cr, "Courier 10 Pitch", 
			 CAIRO_FONT_SLANT_NORMAL, 
			 CAIRO_FONT_WEIGHT_BOLD);
  cairo_set_font_size(cr, 15);
  cairo_move_to(cr, 0,-20);
  cairo_show_text(cr, "f1");
  
  cairo_fill(cr);
  cairo_stroke(cr);

  //f'1
  cairo_identity_matrix(cr);
  cairo_set_source_rgb(cr, 0, 0, 0);
  cairo_translate(cr,glob->centroe1[0]-glob->f1,glob->y*0.35);

  cairo_arc (cr,0, 0, 3, 0, 2*M_PI);
     

  cairo_select_font_face(cr, "Courier 10 Pitch", 
			 CAIRO_FONT_SLANT_NORMAL, 
			 CAIRO_FONT_WEIGHT_BOLD);
  cairo_set_font_size(cr, 15);
  cairo_move_to(cr, 0,-20);
  cairo_show_text(cr, "f'1");
  
  cairo_fill(cr);
  cairo_stroke(cr);
  //f2
  cairo_identity_matrix(cr);
  cairo_set_source_rgb(cr, 0, 0, 0);
  cairo_translate(cr,glob->centroe2[0]+glob->f2,glob->y*0.35);

  cairo_arc (cr,0, 0, 3, 0, 2*M_PI);
     

  cairo_select_font_face(cr, "Courier 10 Pitch", 
			 CAIRO_FONT_SLANT_NORMAL, 
			 CAIRO_FONT_WEIGHT_BOLD);
  cairo_set_font_size(cr, 15);
  cairo_move_to(cr, 0,20);
  cairo_show_text(cr, "f2");
  
  cairo_fill(cr);
  cairo_stroke(cr);

  //f'2
  cairo_identity_matrix(cr);
  cairo_set_source_rgb(cr, 0, 0, 0);
  cairo_translate(cr,glob->centroe2[0]-glob->f2,glob->y*0.35);

  cairo_arc (cr,0, 0, 3, 0, 2*M_PI);
     

  cairo_select_font_face(cr, "Courier 10 Pitch", 
			 CAIRO_FONT_SLANT_NORMAL, 
			 CAIRO_FONT_WEIGHT_BOLD);
  cairo_set_font_size(cr, 15);
  cairo_move_to(cr, 0,20);
  cairo_show_text(cr, "f'2");
  
  cairo_fill(cr);



  //objeto
  cairo_identity_matrix(cr);
  cairo_set_source_rgb (cr, 1, 0, 0);
  cairo_set_line_width(cr, 4);
  cairo_move_to(cr, glob->xobj, glob->y*0.35);
  
  cairo_line_to(cr, glob->xobj, glob->y*0.35-glob->dimobj);
cairo_stroke(cr);
  
  cairo_fill(cr);
  cairo_stroke(cr);
  

  //luz pa criar imagem1
  //raio qe vai pro foco
  if(glob->xobj != glob->centroe1[0])
    {
      cairo_set_source_rgb (cr, 1, 1, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->xobj,glob->y*0.35-glob->dimobj);
      cairo_line_to(cr, glob->centroe1[0],glob->y*0.35-glob->dimobj );
      cairo_stroke(cr);

      cairo_set_source_rgb (cr, 1, 1, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->centroe1[0],glob->y*0.35-glob->dimobj );

      b=((glob->dimobj)/(glob->f1));

	  cairo_line_to(cr, glob->centroe1[0]+glob->f1,glob->y*0.35);
	  cairo_stroke(cr);

 cairo_move_to(cr,  glob->centroe1[0]+glob->f1,glob->y*0.35);
	  if( glob->y*0.35+b*(glob->deltax-glob->f1)<=glob->y*0.35+glob->x*0.06)
	    {
	      cairo_line_to(cr, glob->centroe2[0],glob->y*0.35+b*(glob->deltax-glob->f1));
	      cairo_stroke(cr);
	    }
	  else
	    {
	      cairo_line_to(cr, glob->x*0.6,glob->y*0.35+b*(glob->x*0.6-glob->centroe1[0]-glob->f1));
	      cairo_stroke(cr);
	    }

	
    
      //raio que passa no centro da lente
      cairo_set_source_rgb (cr, 1, 1, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->xobj,glob->y*0.35-glob->dimobj);
      cairo_line_to(cr, glob->centroe1[0],glob->y*0.35);
      cairo_stroke(cr);

      cairo_set_source_rgb (cr, 1, 1, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->centroe1[0],glob->y*0.35);

     
   
      a=((glob->dimobj)/(glob->centroe1[0]-glob->xobj));
    
	  
	  if( glob->y*0.35+a*(glob->deltax)<=glob->y*0.35+glob->x*0.06)// padrao: 300 (ref)+72 ("diametro" em y da elipse)
	    {
	      cairo_line_to(cr, glob->centroe2[0],glob->y*0.35+a*(glob->deltax));
	      cairo_stroke(cr);

	    }
	  else
	    {
	      cairo_line_to(cr, glob->x*0.6,glob->y*0.35+a*(glob->x*0.6-glob->centroe1[0]));
	      cairo_stroke(cr);

	    }
	
     
    }

 //imagem1
  cairo_identity_matrix(cr);
  cairo_set_source_rgb (cr,0 , 1, 0);
  cairo_set_line_width(cr, 4);
  glob->dl1i1=((glob->f1*(glob->centroe1[0]-glob->xobj))/(-glob->f1+(glob->centroe1[0]-glob->xobj)));
//dl1i1=f1*dobjal1/dobjal1-f1
  if((glob->centroe1[0]+glob->dl1i1)<(glob->centroe2[0]))
    {
  glob->xi1=glob->centroe1[0]+glob->dl1i1;
 

  cairo_move_to(cr,glob->xi1, glob->y*0.35);
  

  glob->magl1=(-glob->dl1i1/(glob->centroe1[0]-glob->xobj));
  glob->dimi1=(glob->dimobj*glob->magl1);

  cairo_line_to(cr,glob->xi1, glob->y*0.35-glob->dimi1);
  //ampliaçao=-dl1i1/dobjal1
    }
  else
    {

      glob->xi1=glob->centroe2[0];
      glob->dimi1=0;
    
 
  //glob->dl1i1=((glob->f1*(glob->centroe1[0]-glob->xobj))/(-glob->f1+(glob->centroe1[0]-glob->xobj)));
    }

  cairo_stroke(cr);
  cairo_fill(cr);

//luz real pa criar imagem2

  //raio que vai pro foco
if(glob->centroe1[0]+glob->dl1i1 < glob->centroe2[0] && glob->centroe1[0]+glob->dl1i1>glob->x*0.05 )
  {
      cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->xi1,glob->y*0.35-glob->dimi1);
      cairo_line_to(cr, glob->centroe2[0],glob->y*0.35-glob->dimi1 );
      cairo_stroke(cr);

      cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->centroe2[0],glob->y*0.35-glob->dimi1 );

	  cairo_line_to(cr, glob->centroe2[0]+glob->f2,glob->y*0.35);
	  cairo_stroke(cr);

 cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->centroe2[0]+glob->f2,glob->y*0.35);
      cairo_line_to(cr, glob->x*0.6,glob->y*0.35-(-glob->dimi1/glob->f2)*(glob->x*0.6-(glob->centroe2[0]+glob->f2)));
  cairo_stroke(cr);
      
	
    


    //raio que passa no centro da lente
       cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->xi1,glob->y*0.35-glob->dimi1);
      cairo_line_to(cr, glob->centroe2[0],glob->y*0.35 );
      cairo_stroke(cr);

cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->centroe2[0],glob->y*0.35);

      glob->dl2i1=glob->centroe2[0]-(glob->xi1);
      cairo_line_to(cr, glob->x*0.6,glob->y*0.35-(-glob->dimi1/glob->dl2i1)*(glob->x*0.6-(glob->centroe2[0])));
      cairo_stroke(cr);

    }

//luz virtual pa criar imagem 2

//raio que passa no centro da lente
if(glob->centroe1[0]+glob->dl1i1 < glob->centroe2[0] && glob->centroe1[0]+glob->dl1i1>glob->x*0.05 )
    {
 cairo_set_dash(cr, dashed1, 1, 0);
       cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->xi1,glob->y*0.35-glob->dimi1);

  
 
      cairo_line_to(cr, 0,glob->y*0.35+(-glob->dimi1/glob->dl2i1)*(glob->centroe2[0]));
      cairo_stroke(cr);

      //raio que passa no foco
      cairo_set_dash(cr, dashed1, 1, 0);
      cairo_set_source_rgb (cr, 1, 0.55, 0);
      cairo_set_line_width(cr, 2);
      cairo_move_to(cr, glob->centroe2[0],glob->y*0.35-glob->dimi1);

  
 
      cairo_line_to(cr, 0,glob->y*0.35+(-glob->dimi1/glob->f2)*(glob->centroe2[0]+glob->f2));
      cairo_stroke(cr);


//imagem2
  cairo_identity_matrix(cr);
 cairo_set_dash(cr, dashed1, 0, 0);
  cairo_set_source_rgb (cr,0 , 0, 1);
  cairo_set_line_width(cr, 4);
  glob->dl2i2=fabs(((glob->f2*(glob->dl2i1))/(-glob->f2+(glob->dl2i1))));
 
  if(fabs(glob->dl2i1)<glob->f2)
    {
  glob->xi2=glob->centroe2[0]-glob->dl2i2;

  glob->dl1i2=fabs(glob->centroe1[0]-glob->xi2);
  cairo_move_to(cr,glob->xi2, glob->y*0.35);
  
  glob->magl2=(-glob->dl2i2/(glob->dl2i1));
  glob->dimi2=(fabs(glob->dimi1)*glob->magl2);

  cairo_line_to(cr,glob->xi2, glob->y*0.35-glob->dimi2);
    }
  else
    {
glob->xi2=glob->centroe2[0]+glob->dl2i2;
 glob->dl1i2=fabs(glob->centroe1[0]-glob->xi2);
  cairo_move_to(cr,glob->xi2, glob->y*0.35);
  
  glob->magl2=(-glob->dl2i2/(glob->dl2i1));
  glob->dimi2=(glob->dimi1)*(glob->magl2);

  cairo_line_to(cr,glob->xi2, glob->y*0.35-glob->dimi2);
    }
  cairo_stroke(cr);
  cairo_fill(cr);
    }

      cairo_destroy(cr);
  
      return FALSE;
    }


gboolean
faz_motion_notify (GtkWidget  *widget ,
		   GdkEvent   *event  ,
                   gpointer    data)
{
  global *glob;  
  //int a,b;
  glob=(global *) data;

  /* if(event->type==GDK_CONFIGURE) */
  /*   { */
  /*     a=((glob->centroe1[0])/(glob->x)*0.6); */
  /*     b=((glob->centroe2[0])/(glob->x)*0.6); */

  /*     gtk_window_get_size (GTK_WINDOW(glob->window), &glob->x, &glob->y); */

  /*     glob->centroe1[0]=a*(glob->x)*0.6; */
  /*     glob->centroe2[0]=b*(glob->x)*0.6; */
  /*     glob->centroe1[1]=(glob->y)*0.5; */
  /*     glob->centroe2[1]=(glob->y)*0.5; */
   
  /*   } */ 

  if (event->type == GDK_MOTION_NOTIFY)
    {
      glob->ratoPos[0] = ((GdkEventMotion *)event)->x;
      glob->ratoPos[1] = ((GdkEventMotion *)event)->y;
      if(glob->flag_move==1)
	{

	  if(glob->ratoPos[0]>glob->centroe2[0] && glob->xi1!=glob->centroe2[0]) //tamanho do ref em x - raio da elipse
	    glob->centroe1[0] = glob->centroe2[0];
	  else if(glob->ratoPos[0]<glob->xobj && glob->xi1!=glob->centroe2[0])
	    glob->centroe1[0]=glob->xobj;
	  else if((glob->xi1==glob->centroe2[0] && glob->ratoPos[0] + glob->deltarato>glob->centroe1[0] && glob->centroe1[0]+glob->f1>glob->centroe2[0]-glob->f2) || (glob->xi1==glob->centroe2[0] && glob->ratoPos[0] + glob->deltarato<glob->centroe1[0] && glob->centroe1[0]+glob->f1<glob->centroe2[0]-glob->f2))
	    glob->centroe1[0]=glob->centroe2[0]-glob->deltax;

 else
 glob->centroe1[0] = glob->ratoPos[0] + glob->deltarato;

	}
      if(glob->flag_move==2)
	{
	  if(glob->ratoPos[0]>glob->x*0.6-glob->x*0.0045)
	    glob->centroe2[0] = glob->x*0.6-glob->x*0.0045;
	  else if(glob->ratoPos[0]<glob->centroe1[0])
	    glob->centroe2[0]=glob->centroe1[0];	   
	  else

	    glob->centroe2[0] = glob->ratoPos[0] + glob->deltarato;
	}
    
    }
  else if (event->type == GDK_BUTTON_PRESS)  
    { 
      glob->press[0] = ((GdkEventButton *)event)->x; 
      glob->press[1] = ((GdkEventButton *)event)->y; 
    

      if (glob->press[0]>= (glob->centroe1[0]-glob->x*0.0045)  && glob->press[0]<= (glob->centroe1[0]+glob->x*0.0045) && glob->press[1]>= (glob->centroe1[1]-glob->x*0.06)  && glob->press[1]<= (glob->centroe1[1]+glob->x*0.06) )  
  	{  
	  glob->flag_move = 1; 
	  glob->deltarato= glob->centroe1[0]-glob->press[0]; 
  	}  

      if (glob->press[0]>= (glob->centroe2[0]-glob->x*0.0045)  && glob->press[0]<= (glob->centroe2[0]+glob->x*0.0045) && glob->press[1]>= (glob->centroe2[1]-glob->x*0.06)  && glob->press[1]<= (glob->centroe2[1]+glob->x*0.06) )  
  	{  
	  glob->flag_move = 2;  
	  glob->deltarato= glob->centroe2[0]-glob->press[0]; 
  	}  
    }  
  else if (event->type == GDK_BUTTON_RELEASE) 
    {
      glob->flag_move = 0; 
    }

  gtk_widget_queue_draw (glob->window);
  return FALSE;
}



gboolean
button_clicked(GtkWidget *w,
                gpointer data)
{
  global *glob;
  glob=(global *) data;

 glob->centroe1[0]=(glob->x)*0.1875; //xno ref inicial:181
      glob->centroe1[1]=(glob->y)*0.35;
      glob->centroe2[0]=(glob->x)*0.538333;//xno ref inicial: 520
      glob->centroe2[1]=(glob->y)*0.35;

      gtk_adjustment_set_value (glob->adj[3],20);
 gtk_adjustment_set_value (glob->adj[2],20);
 gtk_adjustment_set_value (glob->adj[1],120);
 gtk_adjustment_set_value (glob->adj[0],100);


  return TRUE;
}

gboolean
button1_clicked(GtkWidget *w,
                gpointer data)
{
  /* global *glob; */
  /* glob=(global *) data; */

  printf("grafico, eventualmente\n");


  return TRUE;
}



gboolean 
change_scale (GtkWidget  *w    , 
	      gpointer    data ) 
{ 
  global    *glob  ; 
 glob=(global *) data; 
 
  gtk_widget_queue_draw (glob->window); 

  return TRUE; 
} 








gboolean                        
faz_resize (GtkWidget  *w    , 
	      gpointer    data ) 
{ 
  gtk_widget_queue_draw (w); 

  return FALSE; 
} 
















/* static gboolean  */
/* time_handler (GtkWidget *widget)  */
/* {  */
/*    if (widget->window == NULL)   */
/*      return FALSE;  */

/*    gtk_widget_queue_draw (widget);  */

/*   return TRUE;  */
/* } */





int
main (int argc, char **argv)
{
  GtkWidget *hbox, *hbox1,*vbox,*vbox1,*label[4],*button[3];
  char str1[30]="Distância Focal da lente 2",str[30]="Distância Focal da lente 1",str2[30]="Posição objeto",str3[30]="Dimensão Objeto";
  global *glob;

  glob=(global *) calloc(1,sizeof(global));
  glob->deltax=-1;
  glob->flag_move=0;


  gtk_init (&argc, &argv);

  //estrutura
  glob->window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_default_size (GTK_WINDOW( glob->window), 1200, 600);
  gtk_window_set_title (GTK_WINDOW ( glob->window), "compila please");
  gtk_window_set_position (GTK_WINDOW ( glob->window), GTK_WIN_POS_CENTER);

  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER ( glob->window), vbox);
 
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_end (GTK_BOX (vbox), hbox, FALSE, FALSE, 20);
 

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_container_add (GTK_CONTAINER (vbox), hbox1);


  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_end (GTK_BOX (hbox1), vbox1, FALSE, FALSE, 20);


 button[0] = gtk_button_new_with_label("Sair");
  gtk_widget_set_size_request(button[0], 80, 35);
 gtk_box_pack_end (GTK_BOX (vbox1), button[0], FALSE, FALSE, 0);
  
g_signal_connect(G_OBJECT(button[0]), "clicked", 
      G_CALLBACK(gtk_main_quit), glob);

 button[1] = gtk_button_new_with_label("Plot");
  gtk_widget_set_size_request(button[1], 80, 35);
 gtk_box_pack_end (GTK_BOX (vbox1), button[1], FALSE, FALSE, 0);
  
g_signal_connect(G_OBJECT(button[1]), "clicked", 
      G_CALLBACK(button1_clicked), glob);

button[2] = gtk_button_new_with_label("Reset");
  gtk_widget_set_size_request(button[2], 80, 35);
 gtk_box_pack_end (GTK_BOX (vbox1), button[2], FALSE, FALSE, 0);
  
g_signal_connect(G_OBJECT(button[2]), "clicked", 
      G_CALLBACK(button_clicked), glob);

 
 
  //ajeitar incrementos dos scales
  //d focal 1
  label[0] = gtk_label_new (str);
  gtk_box_pack_start (GTK_BOX (vbox1), label[0], FALSE, FALSE, 20);
  glob->adj[0] = (GtkAdjustment *)gtk_adjustment_new (100.0, 0.0/* minimo */, 301.0/* maximo */, 0.5, 0.5, 0.5);
  glob->hscale[0] = gtk_hscale_new (GTK_ADJUSTMENT ( glob->adj[0]));
  g_signal_connect (glob->adj[0], "value-changed", G_CALLBACK (change_scale), glob);

  gtk_box_pack_start (GTK_BOX (vbox1),  glob->hscale[0], FALSE, FALSE, 0);

 
  //d focal 2
  label[1] = gtk_label_new (str1);
  gtk_box_pack_start (GTK_BOX (vbox1), label[1], FALSE, FALSE, 20);
  glob->adj[1] = (GtkAdjustment *)gtk_adjustment_new (120.0, 0.0, 301.0, 0.5, 0.5, 1.0);
  glob->hscale[1] = gtk_hscale_new (GTK_ADJUSTMENT ( glob->adj[1]));
  g_signal_connect (glob->adj[1], "value-changed", G_CALLBACK (change_scale), glob);
  gtk_box_pack_start (GTK_BOX (vbox1),  glob->hscale[1], FALSE, FALSE, 0);

  //posição objeto
  label[2] = gtk_label_new (str2);
  gtk_box_pack_start (GTK_BOX (vbox1), label[2], FALSE, FALSE, 20);
  glob->adj[2] = (GtkAdjustment *)gtk_adjustment_new (20.0, 0, 719.0, 0.1, 1.0, 1.0);
  glob->hscale[2] = gtk_hscale_new (GTK_ADJUSTMENT ( glob->adj[2]));
  g_signal_connect (glob->adj[2], "value-changed", G_CALLBACK (change_scale), glob);
  gtk_box_pack_start (GTK_BOX (vbox1),  glob->hscale[2], FALSE, FALSE, 0);

  //dimensão objeto
 label[3] = gtk_label_new (str3);
  gtk_box_pack_start (GTK_BOX (vbox1), label[3], FALSE, FALSE, 20);
  glob->adj[3] = (GtkAdjustment *)gtk_adjustment_new (20.0, 0,100, 0.1, 1.0, 1.0);
  glob->hscale[3] = gtk_hscale_new (GTK_ADJUSTMENT ( glob->adj[3]));
  g_signal_connect (glob->adj[3], "value-changed", G_CALLBACK (change_scale), glob);
  gtk_box_pack_start (GTK_BOX (vbox1),  glob->hscale[3], FALSE, FALSE, 0);

  //lente a mexer com rato
  gtk_widget_set_events ( glob->window, GDK_POINTER_MOTION_MASK | GDK_BUTTON_PRESS_MASK |  GDK_BUTTON_RELEASE_MASK); 

  g_signal_connect ( glob->window, "motion-notify-event", G_CALLBACK (faz_motion_notify), glob); 
  g_signal_connect ( glob->window, "button_press_event", G_CALLBACK (faz_motion_notify), glob); 
  g_signal_connect ( glob->window, "button_release_event", G_CALLBACK (faz_motion_notify), glob);
  //
 g_signal_connect (glob->window, "size-allocate", G_CALLBACK(faz_resize), NULL);
  //g_signal_connect(G_OBJECT(glob->window), "configure-event", G_CALLBACK(faz_motion_notify), glob); GDK_CONFIGURE

  g_signal_connect( glob->window, "expose-event", G_CALLBACK(on_expose_event), glob);
  //g_timeout_add (5, (GSourceFunc) on_expose_event, (gpointer) window);
  g_signal_connect ( glob->window, "destroy", G_CALLBACK(gtk_main_quit),glob);

  gtk_widget_set_app_paintable (glob->window, TRUE);
  gtk_widget_show_all (glob->window);
  gtk_main ();

  return 0;
}
